document.addEventListener("DOMContentLoaded", () => {
    let p = document.querySelector('body');
    let e = document.getElementById("main");
        t = document.getElementById("footer");
        n = document.getElementById("loader");
    setTimeout(() => {
        n.style.display = "none";
        e.style.display = "block";
        p.style.overFlow ='hidden';
        t.style.display = "block";
    }, 600);
});

const hamburger = document.querySelector(".hamburgermenu"),
    navElements = document.querySelector(".navlinks");

hamburger.addEventListener("click", () => {
    hamburger.classList.add("active");
    navElements.classList.add("active");
});

let date = document.getElementById("clock");
function updateTime() {
    let e = new Date(),
        t = e.toLocaleDateString("en-US", {
            weekday: "short",
            year: "numeric",
            month: "short",
            day: "numeric"
        }),
        n = e.toLocaleTimeString("en-US", {
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit"
        });
    date.textContent = `${t} ${n}`;
}
updateTime();
setInterval(updateTime, 1000);

window.addEventListener("scroll", () => {
    let slides = document.querySelectorAll(".slide");
    slides.forEach(e => {
        let t = e.getBoundingClientRect();
        if (t.top < window.innerHeight) e.classList.add("show");
        else if (t.bottom > window.innerHeight) e.classList.remove("show");
    });
});

document.addEventListener("DOMContentLoaded", () => {
    let e = document.querySelector(".hamburgermenu");
    e.classList.add("show");
    setTimeout(() => {
        e.classList.remove("show");
        e.style.zIndex = "100";
    }, 600);
});

const logo = document.querySelector(".home");
logo.addEventListener("click", () => {
    window.location.href = "http://iancovix.netlify.app";
});

const getintouch = document.querySelector(".get-btn");
getintouch.addEventListener("click", () => {
    window.open("https://api.whatsapp.com/send?phone=+256760467887", "_blank");
});

const links = document.querySelectorAll('.links');
links.forEach(link => {
    link.addEventListener('click', () => {
        navElements.classList.toggle('active');
        hamburger.classList.toggle('active');
    });
});

const tooltip = document.querySelector('.tooltip');
tooltip.addEventListener('click', () => {
    navElements.classList.toggle('active');
    hamburger.classList.remove('active');
});

console.log('Portfolio updated on 5th Sep 2025');

// Exampling my self
let age = 8;
if (age < 10) console.log('too young');
else if (age > 20) console.log('how are you');

function user(a, b) {
    let result = a / b;
    console.log(result);
}
user(10, 20);

let name = document.getElementById('name');
let password = document.getElementById('password');

const images = {
    id: "Car",
    image: "./logo.jpg",
    content: "I designed this with all my heart",
};
console.log(images.content);

// form submitting
const form = document.querySelector('form');
form.addEventListener('submit', (e) => {
    e.preventDefault();
    const formData = new FormData(form);
    
    fetch('https://formspree.io/f/xrbygwbb', {
            method: 'POST',
            body: formData,
        })
        .then((response) => response.json())
        .then((data) => console.log(data))
        .catch((error) => console.error(error));
    
    fetch('https://formcarry.com/s/NBrbREXTtEN', {
            method: 'POST',
            body: formData,
        })
        .then((response) => response.json())
        .then((data) => console.log(data));
    form.reset()
        .catch((error) => console.error(error));
    

    const ok = responses.every(response => response.ok);
    
    if (ok) {
        
        
        alert('Message Sent Succrsfully');
    }
    else {
        alert('Please try again later')
    }
    
    
    
});
const obj = { name: 'ian', age: 23, country: 'Uganda' };
console.log(obj.country);

const array = [1, 2, 3, 4, 5];
const dbl = array.map(num => num + 3);
console.log(dbl);

array.forEach(elem => {
    for (let i = 0; i < 10; i++) {
        console.log(i);
    }
});

setTimeout(() => {
    for (let i = 0; i < 10; i++) console.log(i);
}, 1000);

const print = document.createElement('h1');
const body = document.body;

async function fetchData() {
    try {
        const data = [{ name: 'ian', age: 23 }];
        const headers = { 'Content-Type': 'application/json' };
        const body = JSON.stringify(data);
        const response = await fetch('', { method: 'POST', headers, body });
        const result = await response.json();
        const fetchResult = result.map(item => {return`${item.name} : ${item.age}`;}).join('</br>');
        print.innerHTML += fetchResult;
        body += print;
        print.style.color ='white';
    } catch (e) {
        console.error(e);
    }
}
/*
const urls = [
    'https://formcarry.com/s/NBrbREXTtEN',
    'https://formspree.io/f/xrbygwbb'
];

async function sendData() {
    try {
        const request = await fetch(urls, {
            method: 'POST',
            body: new FormData(form)
        });
        const response = await request.json();
        const prom = Promise.all(urls.map(item => {
            let data= `<h1>${response.headline}`;
            let body = document.body;
            body.textContent = data;
        }));
        console.log(prom);
    } catch (error) {
        console.error(error);
    }
}
*/

localStorage.setItem("username", "Ian");
console.log(localStorage.getItem("username"));

const tural = "@";
const rest = 'iancovix@gmail.com';
const result6 = rest.indexOf(tural);
console.log(result6);
async function loadmessage() {
    try {
        const res = await fetch('https://formcarry.com/s/NBrbREXTtEN', {
            method: 'POST',
            headers:{
                'Accept': 'application/json',
                'Content-Type' : 'application/json'},
            body: JSON.stringify({ message: 'A new visitor has been detected' })
        });
        
        const response = 
            await res.text();
        
        console.log(response);
    } catch (error) {
        console.error("Fetch failed:", error);
    }
}
document.addEventListener('DOMContentLoaded', () => loadmessage());